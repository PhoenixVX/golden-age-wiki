package net.minecraft.world.level.storage;

/**
 * Copyright Mojang AB.
 * 
 * Don't do evil.
 */

public class AnvilLevelStorage {

    protected static final int MCREGION_VERSION_ID = 0x4abc;
    protected static final int ANVIL_VERSION_ID = 0x4abd;



}
